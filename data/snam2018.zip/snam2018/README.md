The folder contains 3 files. Each file contains the label (rumor/non-rumor) followed 
by source tweeter and retweeters/repliers in sequential order.
reply_retweet_sequence.txt: Contains both retweeters and repliers.
reply_sequence.txt: Contains only repliers.
retweet_sequence.txt: Contains only retweeters.
